﻿namespace DeepSound.Helpers.Fonts
{
    public enum FontsIconFrameWork
    {
        IonIcons,
        FontAwesomeSolid,
        FontAwesomeRegular,
        FontAwesomeBrands,
        FontAwesomeLight,
        FontAwesomeV3,
        FontAwesomeWebFont
    }

    public enum Fonts
    {
        SfRegular,
        SfSemibold,
        SfMedium
       
    }
}